from flask import Flask, request
from flask_restful import Resource, Api
import json
import datetime
import time

app = Flask(__name__)
api = Api(app)

dictionary  = {}

class ProcessRequest(Resource):
   
    def get(self, key):
        if key == "*":
            return json.dumps(dictionary)
        else:
            return {key: dictionary[key]}

    def put(self, key):
        dataval = request.form['value']
        valarr = dataval.split("@")
        value = valarr[0]
        milli_sec = int(round(time.time() * 1000))
        version =  str(milli_sec)
        valueList = {version:value}
        opt = valarr[1]    
        if opt == "update":
            keys = dictionary.viewkeys()
            for val in keys:
                if val == key:
                    del dictionary[key]
                    dictionary[key] = valueList 
                    return {key: dictionary[key]}

        if key not in dictionary:
            dictionary[key] = valueList
        else:
            myValDict = dictionary[key]
            myValDict[version] = value
            dictionary[key] = myValDict
        return {key: dictionary[key]}

    def delete(self, key):
        val = dictionary[key]
        del dictionary[key]
        return {key:"Removed"}

api.add_resource(ProcessRequest, '/<string:key>')

if __name__ == '__main__':
    app.run(debug=True)
